## 更新记录
-------

#### v0.1.2 ( 2016-3-22 ) ####
 - 更新依赖文件
 - 修改部分component的命名
 - 修改下拉刷新Directive
 - 使用[ISlider](https://github.com/BE-FE/iSlider)替换sui的轮播插件
 - 新增欢迎界面
 - 新增自定义loader
 - 新增无限滚动Directive
 - 新增无限滚动加载更多示例
 - 添加微信分享配置（根据实际情况配置）
 - 添加[Iconfont](http://iconfont.cn/)自定义图标
 - 按需加载组件

-------

#### v0.1.3 ( 2016-3-28 ) ####
 - 修改静态资源目录
 - 修改vue-resource的root设置
 - 修复代码发布后, 无法运行服务的问题

------
