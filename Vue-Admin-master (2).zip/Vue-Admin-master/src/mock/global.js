
module.exports = {
  'GET /menus': function (req, res) {
    res.status(200).json().end()
  },
}
