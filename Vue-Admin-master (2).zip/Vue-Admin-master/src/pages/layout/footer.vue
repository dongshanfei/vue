<template>
  <footer class="main-footer">
    Copyright &copy; 2016-2017 <a href="https://lanux.github.io/Vue-Admin/">Lanux</a>. All rights reserved.
  </footer>
</template>
<script>
  export default {
  }
</script>
<style>
  .main-footer {
    -webkit-transition: -webkit-transform 0.3s ease-in-out, margin 0.3s ease-in-out;
    -moz-transition: -moz-transform 0.3s ease-in-out, margin 0.3s ease-in-out;
    -o-transition: -o-transform 0.3s ease-in-out, margin 0.3s ease-in-out;
    transition: transform 0.3s ease-in-out, margin 0.3s ease-in-out;
    text-align: center;
    padding: 5px 15px;
    color: #444;
    width: 100%;
  }

</style>
