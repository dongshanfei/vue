import footer from "footer.vue";
import header from "header.vue";

export {
  footer,
  header
}
