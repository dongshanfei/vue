// findmusic 推荐
const reconmmed = {
	state: {},
	getters: {},
	mutations: {},
	actions: {}
}
export default reconmmed
