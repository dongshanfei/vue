<template>
	<div class="findsheet">
		<a href="https://github.com/IFmiss/vue-music" target="_black">hihihihi: https://github.com/IFmiss/vue-music</a>
	</div>
</template>
<script>
	export default {
	}
</script>
<style lang="stylus" rel="stylesheet/stylus">
	@import "../../common/stylus/global.styl"
	.findsheet
		position:fixed
		background:#fff
		overflow:auto
		top:86px
		bottom:46px
		left:0
		right:0
		padding:15px
		z-index:11
		background:#fff
		-webkit-overflow-scrolling:touch
		a
			color:#666
			text-decoration:none
</style>
