<template>
	<div class="myCommunity">
		尽情期待!Community
	</div>
</template>
<script>
	export default {
	}
</script>
<style lang="stylus" rel="stylesheet/stylus">
	@import "../../common/stylus/global.styl"
	.myCommunity
		position:fixed
		background:#fff
		overflow:auto
		top:50px
		bottom:46px
		left:0
		right:0
		z-index:911111
		-webkit-overflow-scrolling:touch
</style>
