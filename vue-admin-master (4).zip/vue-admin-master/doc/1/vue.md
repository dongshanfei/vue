
#### 安装vue
    npm i --save-dev vue 

#### 安装vue-router(路由)
    npm i --save-dev vue-router

#### 安装vuex
    npm i --save-dev vuex

#### 安装vue-resource(网络请求)
    npm i --save-dev vue-resource