#### 安装gulp
    npm i --save-dev gulp
#### 安装gulp-minify
    npm i --save-dev gulp-minify
#### 安装gulp-uglify
    npm i --save-dev gulp-uglify
