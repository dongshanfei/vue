
#### 安装webpack到全局
    npm i -g webpack

#### 安装webpack到项目
    npm i --save-dev webpack

#### 安装webpack-dev-server(须和webpack版本兼容)
    npm i --save-dev webpack-dev-server
