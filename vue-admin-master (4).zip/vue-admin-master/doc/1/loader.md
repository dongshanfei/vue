#### 安装style-loader
    npm i --save-dev style-loader

 #### 安装vue-loader
    npm i --save-dev vue-loader

#### 安装css-loader
    npm i --save-dev css-loader
    
####安装babel-loader
    npm i --save-dev babel-loader