import loading from './loading.vue';
export default {
    install :function (Vue) {
        Vue.component('v-loading',loading)
    }
}