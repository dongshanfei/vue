/**
 * Created by zzmhot on 2017/3/24.
 *
 * 状态管理
 *
 * @author: zzmhot
 * @github: https://github.com/zzmhot
 * @email: zzmhot@163.com
 * @Date: 2017/3/24 15:21
 * @Copyright(©) 2017 by zzmhot.
 *
 */

//成功
export const success = 0
//错误
export const error = 1
//未登录
export const unlogin = 2
