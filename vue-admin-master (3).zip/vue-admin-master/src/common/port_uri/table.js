/**
 * Created by zzmhot on 2017/3/24.
 *
 * @author: zzmhot
 * @github: https://github.com/zzmhot
 * @email: zzmhot@163.com
 * @Date: 2017/3/24 16:46
 * @Copyright(©) 2017 by zzmhot.
 *
 */

//数据列表
export const list = "/api/get/table/list"
//根据id查询数据
export const get = "/api/get/table/get"
//根据id删除数据
export const del = "/api/post/table/del"
//添加或修改数据
export const save = "/api/post/table/save"
//批量删除
export const batch_del = "/api/post/table/batch/del"
