/**
 * Created by zzmhot on 2017/3/26.
 *
 * @author: zzmhot
 * @github: https://github.com/zzmhot
 * @email: zzmhot@163.com
 * @Date: 2017/3/26 15:12
 * @Copyright(©) 2017 by zzmhot.
 *
 */

//图片上传
export const image_upload = "/api/post/image/upload"
